(()=>{function u(e){if(document.readyState!=="loading")setTimeout(e,0);else{let t=()=>{removeEventListener("DOMContentLoaded",t),e()};addEventListener("DOMContentLoaded",t)}}var p=chrome;var y="https://api.nopecha.com";var r="https://www.nopecha.com",g="https://developers.nopecha.com",x="https://nopecha.com/api-reference/",L={doc:{url:g,automation:{url:`${g}/guides/extension_advanced/#automation-build`}},ref:{url:x},api:{base:y,status:"/v1/status",recognition:"/v1/recognition",observability:"/v1/observability"},www:{url:r,annoucement:{url:`${r}/json/announcement.json`},demo:{url:`${r}/captcha`,hcaptcha:{url:`${r}/captcha/hcaptcha`},recaptcha:{url:`${r}/captcha/recaptcha`},funcaptcha:{url:`${r}/captcha/funcaptcha`},awscaptcha:{url:`${r}/captcha/awscaptcha`},textcaptcha:{url:`${r}/captcha/textcaptcha`},turnstile:{url:`${r}/captcha/turnstile`},perimeterx:{url:`${r}/captcha/perimeterx`},geetest:{url:`${r}/captcha/geetest`},lemincaptcha:{url:`${r}/captcha/lemincaptcha`}},manage:{url:`${r}/manage`},pricing:{url:`${r}/pricing`},setup:{url:`${r}/setup`}},discord:{url:`${r}/discord`},github:{url:`${r}/github`,release:{url:`${r}/github/release`}}};function b(e){let t=("b846b8843786bdb56cab1cb3b6a719fa11ad88e582614a666f0d1457fac41078"+e).split("").map(s=>s.charCodeAt(0));return h(t)}var f=new Uint32Array(256);for(let e=256;e--;){let t=e;for(let s=8;s--;)t=t&1?3988292384^t>>>1:t>>>1;f[e]=t}function h(e){let t=-1;for(let s of e)t=t>>>8^f[t&255^s];return(t^-1)>>>0}function w(e){return Array.isArray(e)&&e.length>=2&&typeof e[0]=="number"}async function T(e,t){let s=`${[+new Date,performance.now(),Math.random()]}`,i=await new Promise(c=>{try{p.runtime.sendMessage([s,e,...t],n=>{let d=p.runtime.lastError;if(d){d.message,c(void 0);return}if(!w(n)){c(void 0);return}c(n)})}catch(n){c(void 0)}});if(!i)return;let[o,l]=i;if(o===b(s))return l}[...document.body.children].forEach(e=>e.remove());function a(e,t,s={}){let i=document.createElement(e);return s&&Object.entries(s).forEach(([o,l])=>i[o]=l),t.appendChild(i),i}function R(){a("style",document.head,{innerText:`
                * {
                    box-sizing: border-box;
                    word-wrap: break-word;
                }
                html, body {
                    margin: 0;
                    padding: 0;
                }
                body {
                    font-family: monospace, monospace;
                    font-size: 14px;
                    margin: 16px;
                    line-height: 1;
                }

                p {
                    margin-top: 8px;
                    margin-bottom: 8px;
                }
                table {
                    border-collapse: collapse;
                    margin-top: 8px;
                    margin-bottom: 16px;
                }
                th, td {
                    font-size: 14px;
                    border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;
                }
                th {
                    background-color: #f2f2f2;
                }

                .bold {
                    font-weight: bold;
                }
                .small {
                    font-size: 0.825em;
                }
                .red {
                    color: #d9534f;
                }
                .muted {
                    color: #6c757d;
                }
            `})}function E(){a("p",document.body,{innerText:"Invalid URL",className:"bold red"}),a("p",document.body,{innerText:"Please set the URL hash and reload the page."}),a("p",document.body,{innerText:"Example: https://nopecha.com/setup#YOUR_API_KEY",className:"small muted"})}function _(e){return/^(true|false)$/.test(e)?e==="true":/^\d+$/.test(e)?+e:e}function k(){let e="NopeCHA Settings Import",t=document.querySelector("title");document.title!==e&&t&&(t.innerText=e),R();let s=document.location.hash.substring(1);if(!s){E();return}let i=s.split("|"),o=Object.fromEntries(i.map(n=>n.includes("=")?n.split("="):["key",n]).map(([n,d])=>[n,_(d)]));if("disabled_hosts"in o){let n=o.disabled_hosts.join(",");n===""?o.disabled_hosts=[]:decodeURIComponent(n).startsWith("[")?o.disabled_hosts=JSON.parse(decodeURIComponent(n)):o.disabled_hosts=n.split(",")}"key"in o&&o.key.includes(",")&&(o.keys=o.key.split(","),delete o.key),a("p",document.body,{innerText:"Imported settings:",className:"bold"});let l=a("table",document.body),c=a("tr",l);a("th",c,{innerText:"Name"}),a("th",c,{innerText:"Value"}),Object.entries(o).forEach(([n,d])=>{let m=a("tr",l);a("td",m,{innerText:n}),a("td",m,{innerText:JSON.stringify(d)})}),T("settings::update",[o])}u(k);})();
