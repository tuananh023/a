(()=>{function n(e){postMessage({source:"nopecha",...e})}function l(e){n(e)}})();
