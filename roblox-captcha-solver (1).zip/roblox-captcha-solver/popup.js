const apiKeyEl = document.getElementById("apiKey");
const autoSolveEl = document.getElementById("autoSolve");
const delayEl = document.getElementById("delay");
const delayValEl = document.getElementById("delayVal");
const saveBtnEl = document.getElementById("saveBtn");
const statusEl = document.getElementById("status");
const balanceEl = document.getElementById("balance");

// Load settings
const DEFAULT_KEY = "vc_zi1-20Gab7CTi2afsaOHvUxMPcLA15IOlML5yuRWhjY";
chrome.storage.sync.get(["apiKey", "autoSolve", "delay"], (data) => {
  apiKeyEl.value = data.apiKey || DEFAULT_KEY;
  if (data.autoSolve !== undefined) autoSolveEl.checked = data.autoSolve;
  if (data.delay) {
    delayEl.value = data.delay;
    delayValEl.textContent = data.delay + "ms";
  }
  // Fetch balance neu co API key
  fetchBalance(data.apiKey || DEFAULT_KEY);
});

// Delay slider
delayEl.addEventListener("input", () => {
  delayValEl.textContent = delayEl.value + "ms";
});

// Save
saveBtnEl.addEventListener("click", () => {
  const apiKey = apiKeyEl.value.trim();
  const autoSolve = autoSolveEl.checked;
  const delay = parseInt(delayEl.value);

  if (!apiKey) {
    showStatus("Nhap API key truoc!", "error");
    return;
  }

  chrome.storage.sync.set({ apiKey, autoSolve, delay }, () => {
    showStatus("Da luu!", "ok");
    fetchBalance(apiKey);
  });
});

async function fetchBalance(apiKey) {
  try {
    balanceEl.textContent = "...";
    const res = await fetch("https://voltrex.services/captcha/me", {
      headers: { "Authorization": `Bearer ${apiKey}` }
    });
    if (!res.ok) {
      balanceEl.textContent = "Invalid key";
      balanceEl.style.color = "#ff4444";
      return;
    }
    const data = await res.json();
    balanceEl.textContent = "$" + parseFloat(data.balance_usd).toFixed(3);
    balanceEl.style.color = "#00ff88";
  } catch (e) {
    balanceEl.textContent = "Error";
    balanceEl.style.color = "#ff4444";
  }
}

function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.style.color = type === "ok" ? "#00ff88" : "#ff4444";
  setTimeout(() => { statusEl.textContent = ""; }, 2000);
}
