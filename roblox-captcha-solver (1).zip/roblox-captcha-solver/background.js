// Background service worker — goi Voltrex API (tranh CORS)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SOLVE_CAPTCHA") {
    solveCaptha(msg.imageBase64, msg.instruction)
      .then(result => sendResponse({ success: true, index: result }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // async
  }

  if (msg.type === "GET_SETTINGS") {
    chrome.storage.sync.get(["apiKey", "autoSolve", "delay"], data => {
      sendResponse(data);
    });
    return true;
  }
});

async function solveCaptha(imageBase64, instruction) {
  const data = await chrome.storage.sync.get(["apiKey"]);
  const apiKey = data.apiKey;
  const apiKey = data.apiKey || "vc_zi1-20Gab7CTi2afsaOHvUxMPcLA15IOlML5yuRWhjY";

  const form = new FormData();
  form.append("imginstructions", instruction || "default");
  form.append("body", imageBase64);

  const res = await fetch("https://voltrex.services/captcha/v1/im", {
    method: "POST",
    headers: { "Authorization": `Bearer ${apiKey}` },
    body: form
  });

  const text = await res.text();

  if (res.status === 402) throw new Error("Het balance!");
  if (res.status === 401) throw new Error("API key sai!");
  if (res.status === 502) throw new Error("Worker error!");
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${text}`);

  if (!text.startsWith("OK")) throw new Error(`Response la: ${text}`);

  const index = parseInt(text.split("|")[1]);
  if (isNaN(index)) throw new Error(`Index khong hop le: ${text}`);
  return index;
}
