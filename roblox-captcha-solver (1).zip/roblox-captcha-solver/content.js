// Content script — chay tren trang Roblox
// Detect captcha grid va tu dong solve

let isRunning = false;
let observer = null;

// Lay settings
async function getSettings() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, resolve);
  });
}

// Chuyen img element sang base64
function imgToBase64(imgEl) {
  const canvas = document.createElement("canvas");
  canvas.width = imgEl.naturalWidth || imgEl.width;
  canvas.height = imgEl.naturalHeight || imgEl.height;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(imgEl, 0, 0);
  // Tra ve phan sau "data:image/...;base64,"
  return canvas.toDataURL("image/png").split(",")[1];
}

// Lay instruction tu captcha (text mo ta)
function getInstruction() {
  // Roblox hien thi instruction trong cac selector nay
  const selectors = [
    "[class*='challenge-prompt']",
    "[class*='captcha-prompt']",
    "[class*='instructions']",
    "[class*='prompt-text']",
    "label[class*='challenge']",
    "[data-testid*='challenge']",
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && el.innerText.trim()) {
      return el.innerText.trim().toLowerCase().replace(/\s+/g, "_");
    }
  }
  return "default";
}

// Tim captcha image tiles
function findCaptchaTiles() {
  // Roblox dung grid cac img trong challenge modal
  const selectors = [
    "[class*='challenge'] img",
    "[class*='captcha'] img",
    "[id*='captcha'] img",
    "[class*='grid'] img",
    "img[class*='tile']",
    "img[class*='challenge']",
  ];

  for (const sel of selectors) {
    const imgs = [...document.querySelectorAll(sel)];
    if (imgs.length >= 3) return imgs;
  }

  // Fallback: tim img trong modal/overlay
  const modals = document.querySelectorAll(
    "[class*='modal'], [class*='overlay'], [class*='challenge'], [role='dialog']"
  );
  for (const modal of modals) {
    const imgs = [...modal.querySelectorAll("img")];
    if (imgs.length >= 3) return imgs;
  }

  return [];
}

// Tim nut submit/verify
function findSubmitButton() {
  const selectors = [
    "button[class*='submit']",
    "button[class*='verify']",
    "button[class*='confirm']",
    "button[class*='challenge']",
    "button[type='submit']",
    "[class*='challenge'] button",
    "[class*='captcha'] button",
  ];
  for (const sel of selectors) {
    const btn = document.querySelector(sel);
    if (btn && btn.offsetParent !== null) return btn;
  }
  return null;
}

// Click vao tile theo index (1-based)
async function clickTile(tiles, index, delay) {
  const tile = tiles[index - 1];
  if (!tile) {
    console.warn(`[Solver] Khong tim thay tile ${index}`);
    return;
  }
  await sleep(delay);
  tile.click();
  // Simulate mouse events cho chac
  tile.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
  tile.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
  tile.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  console.log(`[Solver] Da click tile ${index}`);
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// Main solve logic
async function trySolve() {
  if (isRunning) return;

  const settings = await getSettings();
  if (!settings.autoSolve) return;
  if (!settings.apiKey) {
    console.warn("[Solver] Chua set API key!");
    return;
  }

  const delay = settings.delay || 500;
  const tiles = findCaptchaTiles();
  if (tiles.length === 0) return;

  console.log(`[Solver] Tim thay ${tiles.length} tiles`);
  isRunning = true;

  try {
    // Doi image load xong
    await sleep(300);

    const instruction = getInstruction();
    console.log(`[Solver] Instruction: ${instruction}`);

    // Lay anh captcha chinh (tile dau tien hoac toan bo grid)
    const mainImg = tiles[0];
    let base64;
    try {
      base64 = imgToBase64(mainImg);
    } catch (e) {
      // Cross-origin image — lay qua src
      console.warn("[Solver] Canvas CORS loi, thu cach khac...");
      isRunning = false;
      return;
    }

    console.log("[Solver] Dang gui len Voltrex API...");
    const result = await chrome.runtime.sendMessage({
      type: "SOLVE_CAPTCHA",
      imageBase64: base64,
      instruction: instruction
    });

    if (!result.success) {
      console.error("[Solver] API loi:", result.error);
      isRunning = false;
      return;
    }

    console.log(`[Solver] API tra ve index: ${result.index}`);
    await clickTile(tiles, result.index, delay);

    // Doi roi submit
    await sleep(delay + 300);
    const submitBtn = findSubmitButton();
    if (submitBtn) {
      submitBtn.click();
      console.log("[Solver] Da bam Submit");
    }

  } catch (err) {
    console.error("[Solver] Loi:", err);
  } finally {
    isRunning = false;
  }
}

// Watch DOM de detect captcha moi xuat hien
function startObserver() {
  if (observer) observer.disconnect();

  observer = new MutationObserver((mutations) => {
    for (const mut of mutations) {
      for (const node of mut.addedNodes) {
        if (node.nodeType !== 1) continue;
        const text = node.className || node.id || "";
        if (/captcha|challenge|overlay|modal/i.test(text)) {
          console.log("[Solver] Phat hien captcha modal!");
          setTimeout(trySolve, 800); // doi render xong
          return;
        }
      }
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  console.log("[Solver] Roblox Captcha Solver dang chay...");
}

// Khoi dong
startObserver();

// Also check ngay khi load (captcha co the da co san)
setTimeout(trySolve, 1500);
