export const defaultConfig = {
  // API key của CapSolver - Đã điền sẵn key của bạn
  apiKey: 'CAI-1703A3B65968C381E18163EC0065B1C1',

  // Your Developer appId, Apply in dashboard's developer section
  appId: '',

  // Kích hoạt extension mặc định
  useCapsolver: true,

  // Tắt chế độ giải thủ công (để AI tự chạy)
  manualSolving: false,

  // Các hàm callback giữ nguyên theo hệ thống
  solvedCallback: 'captchaSolvedCallback',
  solvedFailedCallback: 'captchaSolvedFailedCallback',
  onDetectedCallback: 'onDetectedCallback',

  // Cấu hình Proxy (Nếu chạy tài khoản thường thì để false)
  useProxy: false,
  proxyType: 'http',
  hostOrIp: '',
  port: '',
  proxyLogin: '',
  proxyPassword: '',

  enabledForBlacklistControl: false, 
  blackUrlList: [], 

  // === TẮT CÁC LOẠI CAPTCHA KHÔNG DÙNG ĐỂ TRÁNH LỖI ===
  enabledForRecaptcha: false,
  enabledForRecaptchaV3: false,
  enabledForImageToText: false,
  enabledForAwsCaptcha: false,
  enabledForCloudflare: false,
  enabledForHCaptcha: false,
  
  // === BẬT CHÍNH XÁC FUNCAPTCHA ĐỂ GIẢI ROBLOX ===
  enabledForFunCaptcha: true,       

  // === ÉP CHUYỂN SANG CHẾ ĐỘ AUDIO ĐỂ RẺ TIỀN ===
  // Lưu ý: Nếu Roblox chặn nút Audio của IP/Proxy đó, CapSolver sẽ tự động chuyển về 'click' để xoay hình.
  funCaptchaMode: 'audio',          
  reCaptchaMode: 'click',
  hCaptchaMode: 'click',

  // Delay trước khi giải (để 0 giây để bot nhảy vào giải luôn cho nhanh)
  reCaptchaDelayTime: 0,
  hCaptchaDelayTime: 0,
  textCaptchaDelayTime: 0,
  awsDelayTime: 0,
  funCaptchaDelayTime: 0,

  // Số lần tự động giải lại nếu vòng đó AI làm sai
  reCaptchaRepeatTimes: 10,
  reCaptcha3RepeatTimes: 10,
  hCaptchaRepeatTimes: 10,
  funCaptchaRepeatTimes: 5,        // Thử lại tối đa 5 lần
  textCaptchaRepeatTimes: 10,
  awsRepeatTimes: 10,

  reCaptcha3TaskType: 'ReCaptchaV3TaskProxyLess',
  textCaptchaSourceAttribute: 'capsolver-image-to-text-source', 
  textCaptchaResultAttribute: 'capsolver-image-to-text-result', 
  textCaptchaModule: 'common', 

  // Hiện nút "Solve" trên màn hình để bạn dễ theo dõi bot đang làm gì
  showSolveButton: true, 
};