export const defaultConfig = {
  // API key
  apiKey: 'CAI-1703A3B65968C381E18163EC0065B1C1',

  // Your Developer appId, Apply in dashboard's developer section
  appId: '',

  // Is the extension enabled by default or not
  useCapsolver: true,

  // Solve captcha manually
  manualSolving: false,

  // Captcha solved callback function name
  solvedCallback: 'captchaSolvedCallback',

  // Captcha solved failed callback function name
  solvedFailedCallback: 'captchaSolvedFailedCallback',

  // Captcha detected callback function name
  onDetectedCallback: 'onDetectedCallback',

  // Use proxy or not
  useProxy: false,
  proxyType: 'http',
  hostOrIp: '',
  port: '',
  proxyLogin: '',
  proxyPassword: '',

  enabledForBlacklistControl: false, 
  blackUrlList: [], 

  // === Bật/Tắt các loại Captcha (Bật chính xác Funcaptcha) ===
  enabledForRecaptcha: false,
  enabledForRecaptchaV3: false,
  enabledForImageToText: false,
  enabledForAwsCaptcha: false,
  enabledForCloudflare: false,
  enabledForHCaptcha: false,
  enabledForFunCaptcha: true,       // BẮT BUỘC BẬT: Kích hoạt giải Funcaptcha của Roblox

  // === Chế độ giải Funcaptcha chuẩn của CapSolver ===
  reCaptchaMode: 'click',           // Giữ nguyên mặc định của hệ thống
  hCaptchaMode: 'click',            
  funCaptchaMode: 'click',          // Chuyển sang 'click' để AI tự click xoay hình trên màn hình

  // Delay before solving captcha
  reCaptchaDelayTime: 0,
  hCaptchaDelayTime: 0,
  textCaptchaDelayTime: 0,
  awsDelayTime: 0,
  funCaptchaDelayTime: 0,           // Giải ngay lập tức khi phát hiện captcha

  // Number of repeated solutions after an error
  reCaptchaRepeatTimes: 10,
  reCaptcha3RepeatTimes: 10,
  hCaptchaRepeatTimes: 10,
  funCaptchaRepeatTimes: 5,         // Thử lại tối đa 5 lần nếu một vòng bị lỗi
  textCaptchaRepeatTimes: 10,
  awsRepeatTimes: 10,

  // ReCaptcha V3 task type
  reCaptcha3TaskType: 'ReCaptchaV3TaskProxyLess',

  textCaptchaSourceAttribute: 'capsolver-image-to-text-source', 
  textCaptchaResultAttribute: 'capsolver-image-to-text-result', 

  textCaptchaModule: 'common', 

  showSolveButton: true,            // Bật nút để bạn nhìn thấy tiến trình giải của AI
};