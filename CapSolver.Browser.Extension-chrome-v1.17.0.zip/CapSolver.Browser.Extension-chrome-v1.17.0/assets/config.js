export const defaultConfig = {
  // API key - Nhớ giữ nguyên hoặc thay bằng key chính xác của bạn nhé
  apiKey: 'CAI-1703A3B65968C381E18163EC0065B1C1',

  // Your Developer appId, Apply in dashboard's developer section
  appId: '',

  // Is the extension enabled by default or not
  useCapsolver: true,

  // Solve captcha manually
  manualSolving: false,

  // Captcha solved callback function name
  solvedCallback: 'captchaSolvedCallback',

  // Captcha solved failed callback function name
  solvedFailedCallback: 'captchaSolvedFailedCallback',

  // Captcha detected callback function name
  onDetectedCallback: 'onDetectedCallback',

  // Use proxy or not
  useProxy: false,
  proxyType: 'http',
  hostOrIp: '',
  port: '',
  proxyLogin: '',
  proxyPassword: '',

  enabledForBlacklistControl: false, // Use blacklist control
  blackUrlList: [], // Blacklist URL list

  // === Cấu hình bật/tắt các loại Captcha ===
  enabledForRecaptcha: false,      // Tắt bớt nếu không dùng để nhẹ extension
  enabledForRecaptchaV3: false,    // Tắt bớt
  enabledForImageToText: false,    // Tắt bớt
  enabledForAwsCaptcha: false,     // Tắt bớt
  enabledForCloudflare: false,     // Tắt bớt
  enabledForFunCaptcha: true,      // BẮT BUỘC PHẢI BẬT cái này cho Roblox

  // === ĐỔI SANG CHẾ ĐỘ GIẢI AUDIO ĐỂ TIẾT KIỆM TIỀN ===
  funCaptchaMode: 'audio',         // Thêm/đổi dòng này thành 'audio' (Mặc định thường là 'click' hoặc 'token')

  // Delay before solving captcha
  reCaptchaDelayTime: 0,
  hCaptchaDelayTime: 0,
  textCaptchaDelayTime: 0,
  awsDelayTime: 0,
  funCaptchaDelayTime: 0,          // Thời gian chờ trước khi giải Funcaptcha (để 0 cho nhanh)

  // Number of repeated solutions after an error
  reCaptchaRepeatTimes: 10,
  reCaptcha3RepeatTimes: 10,
  hCaptchaRepeatTimes: 10,
  funCaptchaRepeatTimes: 5,        // Giảm xuống 5 lần thử lại (nếu lỗi quá 5 lần thì bỏ qua đỡ tốn tiền)
  textCaptchaRepeatTimes: 10,
  awsRepeatTimes: 10,

  // ReCaptcha V3 task type
  reCaptcha3TaskType: 'ReCaptchaV3TaskProxyLess',

  textCaptchaSourceAttribute: 'capsolver-image-to-text-source', 
  textCaptchaResultAttribute: 'capsolver-image-to-text-result', 

  textCaptchaModule: 'common', 

  showSolveButton: true, // Hiện nút giải trên màn hình để theo dõi
};