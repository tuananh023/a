export const defaultConfig = {
  // API key
  apiKey: 'CAI-1703A3B65968C381E18163EC0065B1C1',

  // Your Developer appId, Apply in dashboard's developer section
  appId: '',

  // Is the extension enabled by default or not
  useCapsolver: true,

  // Solve captcha manually
  manualSolving: false,

  // Captcha solved callback function name
  solvedCallback: 'captchaSolvedCallback',

  // Captcha solved failed callback function name
  solvedFailedCallback: 'captchaSolvedFailedCallback',

  // Captcha detected callback function name
  onDetectedCallback: 'onDetectedCallback',

  // Use proxy or not
  useProxy: false,
  proxyType: 'http',
  hostOrIp: '',
  port: '',
  proxyLogin: '',
  proxyPassword: '',

  enabledForBlacklistControl: false,
  blackUrlList: [],

  // === CẤU HÌNH CHUẨN ĐỂ ĐÈ FUNCAPTCHA ROBLOX ===
  enabledForRecaptcha: false,
  enabledForRecaptchaV3: false,
  enabledForImageToText: false,
  enabledForAwsCaptcha: false,
  enabledForCloudflare: false,
  enabledForHCaptcha: false,
  
  enabledForFunCaptcha: true,       // BẬT GIẢI FUNCAPTCHA

  // Chế độ click chuẩn để AI tự click chọn hình/xoay hình của Roblox
  reCaptchaMode: 'click',
  hCaptchaMode: 'click',

  // Delay before solving captcha
  reCaptchaDelayTime: 0,
  hCaptchaDelayTime: 0,
  textCaptchaDelayTime: 0,
  awsDelayTime: 0,

  // Number of repeated solutions after an error
  reCaptchaRepeatTimes: 10,
  reCaptcha3RepeatTimes: 10,
  hCaptchaRepeatTimes: 10,
  funCaptchaRepeatTimes: 5,        // Thử lại tối đa 5 lần nếu lỗi
  textCaptchaRepeatTimes: 10,
  awsRepeatTimes: 10,

  reCaptcha3TaskType: 'ReCaptchaV3TaskProxyLess',

  textCaptchaSourceAttribute: 'capsolver-image-to-text-source',
  textCaptchaResultAttribute: 'capsolver-image-to-text-result',

  textCaptchaModule: 'common',

  showSolveButton: true,            // Hiển thị nút Solve để kiểm tra tiến trình
};